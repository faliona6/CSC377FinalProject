Fiona Soetrisno Milestone 1

My game is still an asymetric VR game where one person controls the keyboard and the other controls VR, but instead of working together, the VR player will try to spot the keyboard player out of a crowd of people and try to shoot them.

For this milesone I have the asymmetric VR and keyboard working, grabbable objects for VR, a working gun that raycasts, and a third person player that can run around. I'm not sure how to get the VR perspective shown on my computer, so right now I only have the 3rd person camera to show. But you can see the VR hands and the hands grabbing the gun.